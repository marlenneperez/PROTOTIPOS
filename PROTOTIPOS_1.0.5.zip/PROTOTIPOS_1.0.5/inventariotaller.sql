-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-10-2024 a las 09:17:27
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `inventariotaller`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `herramientas`
--

CREATE TABLE `herramientas` (
  `ID` int(10) UNSIGNED NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `Precio` decimal(10,2) NOT NULL,
  `Cantidad` int(10) UNSIGNED NOT NULL,
  `Estado` enum('En stock','Temporalmente no disponible','Se debe volver a comprar','Agotado') NOT NULL,
  `Imagen` varchar(255) NOT NULL,
  `Notas` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `herramientas`
--

INSERT INTO `herramientas` (`ID`, `Nombre`, `Precio`, `Cantidad`, `Estado`, `Imagen`, `Notas`) VALUES
(27, 'Llave inglesa craftsman 11/16 -11/16', 200.00, 1, 'En stock', '', ''),
(28, 'Llave inglesa surtek 19mm-3/4', 170.00, 1, 'En stock', '', ''),
(29, 'Paquete surtek 9 llaves', 770.00, 9, 'En stock', '', ''),
(30, 'Paquete llave 1(surtek 6.3mm barra 1/4)', 260.00, 1, 'En stock', '', ''),
(31, 'Paquete  llave 2 (7.9mm)', 280.00, 1, 'En stock', '', ''),
(32, 'Paquete llave 3( 9.5mm 3/8)', 200.00, 1, 'En stock', '', ''),
(33, 'Paquete llave 4( 7/16 11.1mm)', 300.00, 1, 'En stock', '', ''),
(35, 'Paquete llave 6(9/16 14.2mm)', 200.00, 1, 'En stock', '', ''),
(36, 'Paquete llave 7(15.8mm 5/8)', 470.00, 1, 'En stock', '', ''),
(37, 'Paquete llave 8(11/17 17.4mm)', 250.00, 1, 'En stock', '', ''),
(38, 'Paquete llave 9(19mm 3/4)', 170.00, 1, 'En stock', '', ''),
(39, 'Llave inglesa craftsman 9mm', 220.00, 1, 'En stock', '', ''),
(40, 'Llave inglesa crafsman 10 mm', 140.00, 1, 'En stock', '', ''),
(41, 'Llave inglesa crafsman 12 mm', 220.00, 1, 'En stock', '', ''),
(42, 'Llave inglesa crafsman 13mm', 360.00, 1, 'En stock', '', ''),
(43, 'Llave inglesa crafsman 14mm', 240.00, 1, 'En stock', '', ''),
(44, 'Llave inglesa crafsman 15mm', 220.00, 1, 'En stock', '', ''),
(45, 'Llave inglesa crafsman 16mm', 265.00, 1, 'En stock', '', ''),
(46, 'Llave inglesa crafsman 3/4', 160.00, 2, 'En stock', '', ''),
(47, 'Llave inglesa surtek 10mm', 210.00, 1, 'En stock', '', ''),
(48, 'Llave inglesa surtek 11mm', 180.00, 1, 'En stock', '', ''),
(49, 'Llave inglesa surtek 12mm', 130.00, 1, 'En stock', '', ''),
(50, 'Llave inglesa surtek 13 mm', 180.00, 1, 'En stock', '', ''),
(51, 'Llave inglesa surtek 15mm', 200.00, 1, 'En stock', '', ''),
(52, 'Cincel urrea 3/8', 115.00, 1, 'En stock', '', ''),
(53, 'Llave inglesa surtek 9/16 14.2mm', 270.00, 1, 'En stock', '', ''),
(54, 'Llave inglesa surtek 15.8mm 5/8', 220.00, 2, 'En stock', '', ''),
(55, 'Llave inglesa surtek 11/16 17.4 mm', 200.00, 1, 'En stock', '', ''),
(56, 'Llave inglesa surtek 19mm 3/4', 150.00, 1, 'En stock', '', ''),
(57, 'Llave inglesa surtek 1/4 6.3mm', 220.00, 1, 'En stock', '', ''),
(58, 'Llave inglesa drop forged 1/4', 270.00, 1, 'En stock', '', ''),
(59, 'Llave inglesa drop forged 5/16', 140.00, 1, 'En stock', '', ''),
(60, 'Llave inglesa drop forged 3/8', 200.00, 1, 'En stock', '', ''),
(61, 'Llave inglesa drop forged 7/16', 250.00, 1, 'En stock', '', ''),
(62, 'Llave inglesa drop forged 9/16', 220.00, 1, 'En stock', '', ''),
(63, 'Llave inglesa urrer 9/16', 300.00, 1, 'En stock', '', ''),
(64, 'Llave inglesa surtek 9/16', 300.00, 1, 'En stock', '', ''),
(65, 'Llave inglesa forged 5/8', 260.00, 1, 'En stock', '', ''),
(66, 'Llave inglesa forged 11/16', 240.00, 2, 'En stock', '', ''),
(67, 'Llave inglesa forged 3/4', 255.00, 1, 'En stock', '', ''),
(68, 'Llave inglesa forged 7/8', 300.00, 2, 'En stock', '', ''),
(69, 'Llave inglesa forged 15/16', 200.00, 1, 'En stock', '', ''),
(70, 'Llave inglesa forgued 1\"', 286.00, 2, 'En stock', '', ''),
(71, 'Llave inglesa forgued 11/8', 200.00, 1, 'En stock', '', ''),
(72, 'Llave inglesa forged 11/4', 225.00, 2, 'En stock', '', ''),
(73, 'Llave inglesa forged 1 5/16', 290.00, 1, 'En stock', '', ''),
(74, 'Llave inglesa forged 1 7/16', 190.00, 2, 'En stock', '', ''),
(75, 'Llave inglesa forged 1 3*8', 255.00, 2, 'En stock', '', ''),
(76, 'Llave inlglesa forged 1 1*2', 280.00, 2, 'En stock', '', ''),
(77, ' Llave inglesa chrome vana dium 6mm', 260.00, 2, 'En stock', '', ''),
(78, 'Llave inglesa chrome vana dium 6mm', 215.00, 2, 'En stock', '', ''),
(79, 'Llave inglesa crftsman 9mm', 150.00, 2, 'En stock', '', ''),
(80, 'Llave inglesa dog forged 10mm', 200.00, 3, 'En stock', '', ''),
(81, 'Llave inglesa dog forgerd 15mm', 240.00, 1, 'En stock', '', ''),
(82, 'Llave inglesa chrome vana dium 11mm', 300.00, 2, 'En stock', '', ''),
(83, 'Llave inlglesa foid 1 1mm', 260.00, 1, 'En stock', '', ''),
(84, 'Llave inglesa pretul 12mm', 150.00, 1, 'En stock', '', ''),
(85, 'Llave inglesa urreal 12mm', 180.00, 1, 'En stock', '', ''),
(86, 'Llave inglesa surtek 12mm', 200.00, 1, 'En stock', '', ''),
(87, 'Llave inglesa chrome vana dium 12mm', 190.00, 1, 'En stock', '', ''),
(88, 'Llave inglesa chrome vana dium 12mm', 190.00, 3, 'En stock', '', ''),
(89, 'Llave inglesa surtek 13mm', 220.00, 1, 'En stock', '', ''),
(90, 'Llave inglesa surtek 14mm', 260.00, 1, 'En stock', '', ''),
(91, 'Llave inglesa petrul 14mm', 240.00, 1, 'En stock', '', ''),
(92, 'Llave inglesa chrome vana dium 14mm', 200.00, 1, 'En stock', '', ''),
(93, 'Llave inglesa urrea 14mm', 300.00, 1, 'En stock', '', ''),
(94, 'lave inglesa surtek 15mm', 280.00, 1, 'En stock', '', ''),
(95, 'Llave inlesa chrome vana dium 15mm', 200.00, 1, 'En stock', '', ''),
(96, 'Llave inglesa craftsman 16mm', 350.00, 1, 'En stock', '', ''),
(97, 'Llave inglesa chrome vana dium 17mm', 220.00, 1, 'En stock', '', ''),
(98, 'Llave inlesa chrome vana dium 18mm', 280.00, 1, 'En stock', '', ''),
(99, 'Llave inglesa chrome vana dium 20mm', 300.00, 1, 'En stock', '', ''),
(100, 'Llave inglesa chrome vana dium 21', 180.00, 1, 'En stock', '', ''),
(101, 'Llave inglesa chrome vana dium 22mm', 240.00, 1, 'En stock', '', ''),
(102, 'Llave inglesa chrome vana dium 25mm', 300.00, 1, 'En stock', '', ''),
(103, 'Llave inlglesa surtek 5*16 ', 250.00, 1, 'En stock', '', ''),
(104, 'Llave inglesa urrer 5*16', 280.00, 1, 'En stock', '', ''),
(105, 'Llave inlglesa surtek 5*16 ', 300.00, 1, 'En stock', '', ''),
(107, 'Llave inglesa  urrer 7*17', 290.00, 2, 'En stock', '', ''),
(108, 'Llave inlgesa urrer 1/2', 250.00, 1, 'En stock', '', ''),
(109, 'Llave inglesa  urrer 1/2 12.7 mm', 260.00, 2, 'En stock', '', ''),
(110, 'Llave inglesa drop forter 9/16', 200.00, 1, 'En stock', '', ''),
(111, 'Llave inglesa toper', 180.00, 2, 'En stock', '', ''),
(112, 'Llave inglesa urrer', 250.00, 1, 'En stock', '', ''),
(113, 'Llave inglesa urrer  5/8', 300.00, 3, 'En stock', '', ''),
(114, 'Llave inglesa uper  11/16 17.4m', 260.00, 1, 'En stock', '', ''),
(115, 'Llave inglesa urrer 11/16', 220.00, 1, 'En stock', '', ''),
(116, 'Llave inglesa surtek 3/4 19m', 280.00, 1, 'En stock', '', ''),
(117, 'Llave inglesa urrer 3/4', 300.00, 2, 'En stock', '', ''),
(118, 'Llave inglesa uper 13/16 20.6m', 320.00, 1, 'En stock', '', ''),
(119, 'Llave inglesa urrer 7/86', 200.00, 1, 'En stock', '', ''),
(120, 'Llave inglesa chome vanadium  1/4', 180.00, 1, 'En stock', '', ''),
(121, 'Llave inglesa drop forguet  5/8', 250.00, 1, 'En stock', '', ''),
(122, 'Llave inglesa drop forguet  1/2', 150.00, 1, 'En stock', '', ''),
(123, 'Llave inglesa chome vanadium 3/4', 190.00, 1, 'En stock', '', ''),
(124, 'Llave inglesa  drop forguet 13/16', 200.00, 1, 'En stock', '', ''),
(125, 'Cincho  de filto de acite tipo arañas', 200.00, 1, 'En stock', '', ''),
(126, 'Cincho  de filtro aceite truper', 175.00, 7, 'En stock', '', ''),
(127, 'Cincel urrea 3/8', 150.00, 1, 'En stock', '', ''),
(128, 'Cincel uper 5/8', 150.00, 2, 'En stock', '', ''),
(129, 'Cincel uper 1/2', 150.00, 2, 'En stock', '', ''),
(130, 'Cincel urrer 3/4', 150.00, 2, 'En stock', '', ''),
(131, 'Cincel urrer 7/8', 150.00, 2, 'En stock', '', ''),
(132, 'Cilindro porta grasa  ideal', 1500.00, 1, 'En stock', '', ''),
(133, 'Dado de impacto uper 10mm', 170.00, 1, 'En stock', '', ''),
(134, 'Dado de impacto urrer11mm', 300.00, 1, 'En stock', '', ''),
(135, 'Dado de impacto urrer 12mm', 280.00, 1, 'En stock', '', ''),
(136, 'Dado de impacto urer 13mm', 260.00, 1, 'En stock', '', ''),
(137, 'Dado de impacto urrer 14mm', 160.00, 1, 'En stock', '', ''),
(138, 'Dados de impacto urrer 15mm', 260.00, 1, 'En stock', '', ''),
(139, 'Dados de impacto urrer 16mm', 260.00, 1, 'En stock', '', ''),
(140, 'Dados de impacto urrer 17mm', 280.00, 1, 'En stock', '', ''),
(141, 'Dados de impacto urrer 18mm', 260.00, 1, 'En stock', '', ''),
(142, 'Dados de impacto urrer 19mm', 330.00, 1, 'En stock', '', ''),
(143, 'Dados de impacto uurer 20mm', 240.00, 1, 'En stock', '', ''),
(144, 'Dados de impacto urrer 21mm', 360.00, 1, 'En stock', '', ''),
(145, 'Dados de impacto urrer 22mm', 260.00, 1, 'En stock', '', ''),
(146, 'Dados de impacto urrer 23mm', 260.00, 1, 'En stock', '', ''),
(147, 'Dados de impacto urrer 24mm', 260.00, 1, 'En stock', '', ''),
(148, 'Dado  de impacto urrer 14mm', 170.00, 1, 'En stock', '', ''),
(149, 'Dado de impacto  13mm', 360.00, 1, 'En stock', '', ''),
(150, 'Dado de impacto urrer 12mm', 260.00, 1, 'En stock', '', ''),
(151, 'Dado de impacto urrer 11mm', 260.00, 1, 'En stock', '', ''),
(152, 'Dado de impacto urrer 11mm', 260.00, 1, 'En stock', '', ''),
(153, 'Dado de impacto urrer 15mm', 170.00, 1, 'En stock', '', ''),
(154, 'Dado de impacto urrer 16mm', 260.00, 1, 'En stock', '', ''),
(155, 'Dado de impacto urrer 17mm', 280.00, 1, 'En stock', '', ''),
(156, 'Dado de impacto urrer 18mm', 250.00, 1, 'En stock', '', ''),
(157, 'Dado de impacto urrer 19mm', 260.00, 1, 'En stock', '', ''),
(158, 'Dado punta exagonal urrer 3/8', 160.00, 1, 'En stock', '', ''),
(159, 'Dado punta exagonal urrer 7/16', 200.00, 2, 'En stock', '', ''),
(160, 'Dado punta allen urrer  5/16 ', 135.00, 1, 'En stock', '', ''),
(161, 'Dado punta allen urrer 3/8', 200.00, 1, 'En stock', '', ''),
(162, 'Dado punta allen urrer1/2', 172.00, 2, 'En stock', '', ''),
(163, ' Dado punta allen  urrer 9/16 ', 165.00, 2, 'En stock', '', ''),
(164, 'Dado punta allen 5/8', 120.00, 2, 'En stock', '', ''),
(165, 'Dado punta estrella 9mm', 200.00, 1, 'En stock', '', ''),
(166, 'Dado punta estrella 9/10mm', 170.00, 2, 'En stock', '', ''),
(167, 'Dado punta estrella 12m', 150.00, 1, 'En stock', '', ''),
(168, 'Dado punta estrella 14m', 160.00, 1, 'En stock', '', ''),
(169, 'Dado punta estrella 16m', 140.00, 1, 'En stock', '', ''),
(170, 'Dado punta estrella 20torks', 170.00, 1, 'En stock', '', ''),
(171, ' Dado punta estrella 10 torks', 245.00, 1, 'En stock', '', ''),
(172, 'Dado punta estrella 25 torks ', 225.00, 1, 'En stock', '', ''),
(173, 'Dado punta estrella 27 torks ', 175.00, 1, 'En stock', '', ''),
(174, 'Dado punta estrella 40 torks ', 130.00, 1, 'En stock', '', ''),
(175, 'Dado punta estrella 45 torks ', 123.00, 1, 'En stock', '', ''),
(176, 'Dado punta estrella 30 torks ', 140.00, 1, 'En stock', '', ''),
(177, 'Dado punta estrella 30 torks ', 110.00, 1, 'En stock', '', ''),
(178, 'Juego de Dados torx de seguridad ', 360.00, 12, 'En stock', '', ''),
(179, 'Dados torx urrer t8', 277.00, 2, 'En stock', '', ''),
(180, 'Dados torx urrer t9 ', 220.00, 2, 'En stock', '', ''),
(181, 'Dados torx urrert10  ', 237.00, 2, 'En stock', '', ''),
(182, 'Dados torx urrer t15  ', 281.00, 2, 'En stock', '', ''),
(183, 'Dados torx urrer t20', 150.00, 2, 'En stock', '', ''),
(184, 'Dados torx urrer t27 ', 130.00, 2, 'En stock', '', ''),
(185, 'Dados torx urrer t30', 283.00, 2, 'En stock', '', ''),
(186, 'Dados torx urrer t40 ', 256.00, 2, 'En stock', '', ''),
(187, 'Dados torx urrer t45 ', 245.00, 2, 'En stock', '', ''),
(188, ' Dados torx urrer t50 ', 200.00, 2, 'En stock', '', ''),
(189, 'Dados torx urrer t55', 150.00, 2, 'En stock', '', ''),
(190, 'Dados torx urrer t60', 200.00, 2, 'En stock', '', ''),
(191, 'Dados urrer  27mm', 113.00, 2, 'En stock', '', ''),
(192, 'Dados urrer 26mm', 100.00, 2, 'En stock', '', ''),
(193, 'Dados urrer 11mm', 172.00, 1, 'En stock', '', ''),
(194, 'Dado urrer 12mm', 150.00, 1, 'En stock', '', ''),
(195, 'Dado urrer 14mm', 140.00, 1, 'En stock', '', ''),
(196, 'Dado urrer 16mm', 150.00, 1, 'En stock', '', ''),
(197, 'Dado urrer 17mm', 165.00, 1, 'En stock', '', ''),
(198, 'Dado urrer 18mm', 143.00, 1, 'En stock', '', ''),
(199, 'Dado urrer 19mm', 150.00, 11, 'En stock', '', ''),
(200, 'Dado  urre 12mm', 160.00, 2, 'En stock', '', ''),
(201, 'Dado urrer 13mm', 140.00, 1, 'En stock', '', ''),
(202, 'Dado urrer 14mm', 135.00, 1, 'En stock', '', ''),
(203, 'Dado urrer 15mm', 160.00, 1, 'En stock', '', ''),
(204, 'Dado urrer 16mm', 155.00, 1, 'En stock', '', ''),
(205, 'Dado urrer 18mm', 160.00, 1, 'En stock', '', ''),
(206, 'Dado urrer 19mm', 210.00, 1, 'En stock', '', ''),
(207, 'Dado urrer 20mm', 141.00, 1, 'En stock', '', ''),
(208, 'Dado urrer 21mm', 130.00, 1, 'En stock', '', ''),
(209, 'Dado urrer 22mm', 161.00, 1, 'En stock', '', ''),
(210, 'Dado urrer 23mm', 178.00, 1, 'En stock', '', ''),
(211, 'Dado urrer 25mm', 200.00, 1, 'En stock', '', ''),
(212, 'Dado urrer 3/8', 100.00, 1, 'En stock', '', ''),
(213, 'Dado urrer 7/16', 200.00, 1, 'En stock', '', ''),
(214, 'Dado urrer 9/16', 200.00, 0, 'Temporalmente no disponible', '', ''),
(215, 'Dado urrer 5/8', 102.00, 0, 'Temporalmente no disponible', '', ''),
(216, 'Dado urrer 11/16', 135.00, 0, 'Temporalmente no disponible', '', ''),
(217, 'Dado urrer 3/4', 300.00, 0, 'Temporalmente no disponible', '', ''),
(218, 'Dado urrer 13/16', 160.00, 0, 'Temporalmente no disponible', '', ''),
(219, 'Dado urrer 7/8', 100.00, 0, 'Temporalmente no disponible', '', ''),
(220, 'Dado urrer 3/8  9.52mm', 171.00, 0, 'Temporalmente no disponible', '', ''),
(221, 'Dado urrer 7/16   1entero 1mm', 380.00, 0, 'Temporalmente no disponible', '', ''),
(222, 'Dado 1/2   12.79mm', 176.00, 0, 'Temporalmente no disponible', '', ''),
(223, 'Dado urrer 9/17  14.25mm', 2369.00, 0, 'Temporalmente no disponible', '', ''),
(224, ' Dado urrer 5/8   15.8mm', 260.00, 0, 'Temporalmente no disponible', '', ''),
(225, ' Dado urrer 11/16  17.46mm', 230.00, 0, 'Temporalmente no disponible', '', ''),
(226, 'Dado urrer 3/4  19.05mm', 665.00, 0, 'Temporalmente no disponible', '', ''),
(227, ' Dado urrer 13/17  20.63mm', 538.00, 0, 'Temporalmente no disponible', '', ''),
(228, ' Dado urrer 7/8 22.22mm', 500.00, 0, 'Temporalmente no disponible', '', ''),
(229, ' Dado urrer  7/8 ', 400.00, 0, 'Temporalmente no disponible', '', ''),
(230, ' Dado urrer 13/16', 172.00, 2, 'En stock', '', ''),
(231, 'Dado urrer 3/4  ', 450.00, 0, 'Temporalmente no disponible', '', ''),
(232, 'Dado urrer 5/8', 666.00, 0, 'Temporalmente no disponible', '', ''),
(233, 'Dado urrer 7/16', 478.00, 2, 'En stock', '', ''),
(234, 'Dado urrer 3/8  ', 100.00, 0, 'Temporalmente no disponible', '', ''),
(235, 'Dado urrer  7/8', 700.00, 4, 'En stock', '', ''),
(236, ' Dado urrer 1entero ', 660.00, 4, 'En stock', '', ''),
(237, ' Dado urrer 1 entero 1/16', 226.00, 4, 'En stock', '', ''),
(238, ' Dado urrer 1 entero 1/8', 300.00, 4, 'En stock', '', ''),
(239, ' Dado urrer 1 entero 3/16', 220.00, 4, 'En stock', '', ''),
(240, ' Dado urrer 1 entero 1/4', 390.00, 4, 'En stock', '', ''),
(241, ' Juego de llave allen', 85.00, 2, 'En stock', '', ''),
(242, ' T-llave de bujias', 205.00, 2, 'En stock', '', ''),
(243, ' Juego de llaves torx', 2705.00, 3, 'En stock', '', ''),
(244, 'Juego de llave torx (1) t30', 788.00, 1, 'En stock', '', ''),
(245, 'Juego de llave torx (2) t40', 674.00, 1, 'En stock', '', ''),
(246, ' Juego de llave torx (3) t45', 394.00, 1, 'En stock', '', ''),
(247, ' Juego de llave torx (4) t50', 260.00, 1, 'En stock', '', ''),
(248, ' Juego de llave torx (5) t15', 506.00, 1, 'En stock', '', ''),
(249, ' Juego de llave torx (6) t20', 400.00, 1, 'En stock', '', ''),
(250, ' Juego de llave torx (7)  t25', 513.00, 1, 'En stock', '', ''),
(251, ' Juego de llave torx (8) t27', 600.00, 1, 'En stock', '', ''),
(252, 'Juego de mini  llave tipo allen punta', 139.00, 1, 'En stock', '', ''),
(253, 'Llave quita tachones', 100.00, 1, 'En stock', '', ''),
(254, ' Extractor de baleros', 1999.00, 1, 'En stock', '', ''),
(255, ' Llave francessa 2.54mm', 707.00, 1, 'En stock', '', ''),
(256, ' Llave francessa 512-s', 1676.00, 1, 'En stock', '', ''),
(257, ' Llave periquera 457mm', 377.00, 1, 'En stock', '', ''),
(258, ' Llave stylson 1entero 1/2', 5712.00, 1, 'En stock', '', ''),
(259, ' Llave stylson 600mm', 2738.00, 1, 'En stock', '', ''),
(260, 'Caja de herramientas', 505.00, 3, 'En stock', '', ''),
(261, 'Pinza fija anillos', 540.00, 3, 'En stock', '', ''),
(262, 'Pinza para bujia', 995.00, 2, 'En stock', '', ''),
(263, 'Pinzas para quitar seguro de balero', 806.00, 7, 'En stock', '', ''),
(264, 'Pinzas parea capuchones de bujias', 699.00, 2, 'En stock', '', ''),
(265, 'Pinzas pela cable ', 1063.00, 13, 'En stock', '', ''),
(266, ' Pinzas mecanicas foil', 151.00, 9, 'En stock', '', ''),
(267, ' Pinzas mecanicas urrer 27/6', 473.00, 1, 'En stock', '', ''),
(268, ' Pinzas mecanicas fortem 6mm', 114.00, 2, 'En stock', '', ''),
(269, ' Pinzas mecanicas foil  gel', 2160.00, 2, 'En stock', '', ''),
(270, 'Alicate para punta ', 74.00, 2, 'En stock', '', ''),
(271, ' Pinza de extencion', 897.00, 2, 'En stock', '', ''),
(272, ' Pinzas normales', 286.00, 2, 'En stock', '', ''),
(273, ' Pinza de punta conica', 150.00, 2, 'En stock', '', ''),
(274, ' Pinza corte diagonal', 2160.00, 2, 'En stock', '', ''),
(275, ' Cinta metrica marca petrul', 357.00, 1, 'En stock', '', ''),
(276, ' Multi navaja', 495.00, 1, 'En stock', '', ''),
(277, ' Pinzas para anillo de retencion', 81.00, 2, 'En stock', '', ''),
(278, 'Bayoneta de aceite', 600.00, 2, 'En stock', '', ''),
(279, 'Pinzas de precion', 235.00, 4, 'En stock', '', ''),
(280, ' Punta de soplete', 180.00, 1, 'En stock', '', ''),
(281, 'Calibradores', 375.00, 2, 'En stock', '', ''),
(282, ' Tenaza de carpintero', 155.00, 1, 'En stock', '', ''),
(283, ' Alicate', 100.00, 2, 'En stock', '', ''),
(285, ' Llave de copa', 361.00, 5, 'En stock', '', ''),
(286, ' Llave de copa con punta', 172.00, 2, 'En stock', '', ''),
(287, 'Medidor de energia para las baterias  foxwell', 2181.00, 1, 'En stock', '', ''),
(288, 'Llave para contratuerca mini pulidora', 333.00, 1, 'En stock', '', ''),
(289, 'Mango telescopico ', 30.00, 2, 'En stock', '', ''),
(290, 'Inflador de llantas', 495.00, 1, 'En stock', '', ''),
(291, '  Medidores de precion', 2000.00, 8, 'En stock', '', ''),
(292, '  Telescopio magneto urrer', 273.00, 1, 'En stock', '', ''),
(293, ' Juego de desconectores urrer', 200.00, 1, 'En stock', '', ''),
(294, '  Deteccion de corriente de sircuitos surtec', 120.00, 2, 'En stock', '', ''),
(295, ' Barras de ajustador surtek', 693.00, 5, 'En stock', '', ''),
(296, ' Extractor de placas de direccion ', 491.00, 1, 'En stock', '', ''),
(297, ' Carda (4 empaques)', 120.00, 1, 'En stock', '', ''),
(298, ' Hydrometros de bateria', 348.00, 2, 'En stock', '', ''),
(299, ' Desarmador marca urrer punta cruz', 720.00, 10, 'En stock', '', ''),
(300, ' Derarmador plano urrer', 720.00, 10, 'En stock', '', ''),
(301, 'Dasrmador planto tulmex', 720.00, 5, 'En stock', '', ''),
(302, ' Desarmador staley plano', 85.00, 1, 'En stock', '', ''),
(303, ' Desarmador tulmex plano', 74.00, 5, 'En stock', '', ''),
(304, '  Serruchos', 201.00, 3, 'En stock', '', ''),
(305, '  Separador de balatas urrer', 348.00, 2, 'En stock', '', ''),
(306, ' Alicate de artesano', 237.00, 2, 'En stock', '', ''),
(307, ' Separador de terminal de direccion y rotula powerbuilt', 1263.00, 1, 'En stock', '', ''),
(308, ' Tijera de hojalatero', 238.00, 1, 'En stock', '', ''),
(309, ' Motor y sistema electico ', 185.00, 3, 'En stock', '', ''),
(310, ' Compresor de balbulas', 12122.00, 3, 'En stock', '', ''),
(311, '  Cable pasa corriente', 67.00, 3, 'En stock', '', ''),
(312, ' Laboratoro de inyectores de gasolina', 67.00, 1, 'En stock', '', ''),
(313, ' Matraca foil 3/8', 2900.00, 1, 'En stock', '', ''),
(314, ' Matraca urrea', 1400.00, 3, 'En stock', '', ''),
(315, ' Matraca truper ', 224.00, 2, 'En stock', '', ''),
(316, ' Matraca surtec ', 1384.00, 3, 'En stock', '', ''),
(317, ' Maneral  urrea  1 entero', 1911.00, 1, 'En stock', '', ''),
(318, ' Maneral truper 1/2', 255.00, 1, 'En stock', '', ''),
(319, ' Maneral truper', 700.00, 1, 'En stock', '', ''),
(320, 'Maneral foil', 689.00, 1, 'En stock', '', ''),
(321, 'Luz negra 3377', 200.00, 1, 'Temporalmente no disponible', '', ''),
(322, ' Inductive timing analyzer tl-5100', 700.00, 2, 'En stock', '', ''),
(323, ' Consumo de energia electrica  por unidad de tiempo en operacion', 1200.00, 2, 'En stock', '', ''),
(324, 'Cutin', 151.00, 2, 'Temporalmente no disponible', '', ''),
(325, 'Refrigerantes', 179.00, 4, 'En stock', '', ''),
(326, ' Gato hidraulico', 9594.00, 1, 'En stock', '', ''),
(327, ' Liquido de frenos', 140.00, 1, 'Se debe volver a comprar', '', ''),
(328, ' Extractor de poleas', 444.00, 4, 'En stock', '', ''),
(329, 'Paquete de brocas surtek', 1794.00, 1, 'En stock', '', ''),
(330, '  Mini esmeriladora neumatica de boquilla ', 7897.00, 1, 'En stock', '', ''),
(331, ' Monas(torres hidraulicas)', 694.00, 2, 'En stock', '', ''),
(332, 'wd-40 (afloja todo)', 411.00, 3, 'En stock', '', ''),
(333, 'Stuche de juego de Dados con matraca urrea', 5170.00, 2, 'En stock', '', ''),
(334, 'Juego de juego de Dados con desarmador porta lienzos 17 urrea ', 5170.00, 2, 'En stock', '', ''),
(335, 'Paquete de Dados estandar petrul', 582.00, 2, 'En stock', '', ''),
(336, ' Medidores digitales truper', 5852.00, 9, 'En stock', '', ''),
(337, ' Brocha petrul', 63.00, 1, 'En stock', '', ''),
(338, 'Juego de machuelos y tarrajas', 573.00, 1, 'En stock', '', ''),
(339, ' Compresor de resortes de suspencion', 573.00, 6, 'En stock', '', ''),
(340, ' Kit de deteccion de fugas', 943.00, 2, 'En stock', '', ''),
(341, ' Rollo de alambre para soldar', 6890.00, 1, 'En stock', '', ''),
(342, ' Crema para soldar', 120.00, 1, 'En stock', '', ''),
(343, ' Juego de brocas recomendada para machueleal', 110.00, 1, 'En stock', '', ''),
(344, ' sensores de oxigeno', 1453.00, 2, 'En stock', '', ''),
(345, ' Juego maestro de reparacion de hilos', 964.00, 2, 'En stock', '', ''),
(346, ' Juego de punzones', 290.00, 2, 'En stock', '', ''),
(347, ' caretas para soldar', 494.00, 4, 'Temporalmente no disponible', '', '3 en funcion 1 sin funcionar'),
(348, ' Kit de soporte inferior', 925.00, 2, 'En stock', '', ''),
(349, ' Lampara', 833.00, 2, 'En stock', '', ''),
(350, ' Juego de herramientas para extraccion 316', 560.00, 2, 'En stock', '', ''),
(351, ' Kit de taladro 1000 milwaukee', 5100.00, 1, 'En stock', '', ''),
(352, ' Correa de aniño de piston', 890.00, 3, 'Temporalmente no disponible', '', ''),
(353, ' Kit de Dados', 590.00, 6, 'En stock', '', ''),
(354, ' Manguera de aire', 395.00, 4, 'En stock', '', ''),
(355, ' Paquete de sinchos', 1940.00, 1, 'En stock', '', ''),
(356, ' Paquete de remaches marca fiero', 200.00, 2, 'Temporalmente no disponible', '', ''),
(357, ' Cople rapido macho surtek', 330.00, 6, 'En stock', '', ''),
(358, ' Cople rapido hembra surtek', 288.00, 4, 'En stock', '', ''),
(359, ' Juego de llave allen tipo nabaja truper', 971.00, 1, 'En stock', '', ''),
(360, ' Silicon negro', 463.00, 7, 'En stock', '', ''),
(361, ' Visagra cuadrada de acero', 260.00, 1, 'Se debe volver a comprar', '', ''),
(362, ' Paquete de seguetas', 1300.00, 13, 'En stock', '', ''),
(363, ' Paquete de electrodo', 900.00, 2, 'En stock', '', ''),
(364, ' Juego de desarmadores', 720.00, 1, 'En stock', '', ''),
(365, ' Aceite para motro marca movil', 300.00, 1, 'En stock', '', ''),
(366, ' Aceite para transimicion marca servicio pro', 844.00, 1, 'En stock', '', ''),
(367, ' Aceite para transicion automatica para motor ', 435.00, 1, 'En stock', '', ''),
(368, ' Limpiador de inyectores para boya', 235.00, 1, 'En stock', '', ''),
(369, ' Acido cloruro de sodio', 522.00, 1, 'Temporalmente no disponible', '', ''),
(370, ' Estabilizador de Aceite de alto rendiimiento marca lucas', 380.00, 0, 'Se debe volver a comprar', '', ''),
(371, ' Aceite multiuso marca singler', 766.00, 0, 'Se debe volver a comprar', '', ''),
(372, ' Crema limpiadora para manos marca tf', 200.00, 0, 'Se debe volver a comprar', '', ''),
(373, ' Vulvo motoventilador chevi', 991.00, 1, 'Temporalmente no disponible', '', ''),
(374, ' Interruptor de serraguero de carro marca roi', 788.00, 1, 'Temporalmente no disponible', '', ''),
(375, ' Transformador encendido', 1480.00, 1, 'En stock', '', ''),
(376, ' Regulador electronico marca golden vand', 1495.00, 2, 'Temporalmente no disponible', '', ''),
(377, ' Foco de alojeno', 1225.00, 1, 'Temporalmente no disponible', '', ''),
(378, ' Siuick de luces intermitentes', 235.00, 1, 'Temporalmente no disponible', '', ''),
(379, ' Reguladores marca elvac', 1230.00, 4, 'Temporalmente no disponible', '', ''),
(380, ' Tapa para distribuidor', 512.00, 1, 'Temporalmente no disponible', '', ''),
(381, ' Bicarbonato de sodio ppuro', 1043.00, 1, 'Se debe volver a comprar', '', ''),
(382, ' Serradura de panal', 533.00, 1, 'Temporalmente no disponible', '', ''),
(383, ' Bobina de igmision marca ifuel', 700.00, 1, 'Temporalmente no disponible', '', ''),
(384, ' Carter producto deliberado', 48.00, 1, 'Temporalmente no disponible', '', ''),
(385, ' Pegamento ft100', 150.00, 1, 'Temporalmente no disponible', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reciclaje`
--

CREATE TABLE `reciclaje` (
  `ID` int(10) UNSIGNED NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `Precio` decimal(10,2) NOT NULL,
  `Cantidad` int(10) UNSIGNED NOT NULL,
  `Estado` enum('En stock','Temporalmente no disponible','Se debe volver a comprar','Agotado') NOT NULL,
  `Imagen` varchar(255) NOT NULL,
  `Notas` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reciclaje`
--

INSERT INTO `reciclaje` (`ID`, `Nombre`, `Precio`, `Cantidad`, `Estado`, `Imagen`, `Notas`) VALUES
(1, 'Llave inglesa combinada 18 mm', 180.00, 1, 'En stock', '', 'Llave combinada de 18mm esta fabricada de acero tratado para mayor resistencia es ideal para tuercas y tornillos de cabeza hexagonal'),
(2, 'Llave inglesa combinada 15mm a 12 mm', 202.00, 1, 'En stock', '', ''),
(3, 'Llave inglesa combinada 3/4', 130.00, 1, 'En stock', '', ''),
(4, 'Llave inglesa combinada  5/8', 120.00, 1, 'En stock', '', ''),
(5, 'Llave inglesa combinada 9/16', 274.00, 1, 'En stock', '', ''),
(6, 'Llave inglesa combinada  7/16', 274.00, 1, 'En stock', '', ''),
(7, 'Llave inglesa combinada  3/8', 356.00, 1, 'En stock', '', ''),
(8, 'Llave inglesa combinada  5 /16', 193.00, 1, 'En stock', '', ''),
(9, 'Matraca combinada 3/4 -7/8', 401.00, 1, 'En stock', '', ''),
(10, ' Matraca combinada 5/8 - 11/16', 456.00, 1, 'En stock', '', ''),
(11, 'Matraca combinada 1/2- 9/16', 440.00, 1, 'En stock', '', ''),
(12, 'Matraca combinada 3/8- 7/16', 325.00, 1, 'En stock', '', ''),
(13, 'Matraca combinada 1/4 - 15/16', 320.00, 1, 'En stock', '', ''),
(14, 'Matraca combinada 19/21', 459.00, 1, 'En stock', '', ''),
(15, 'Matraca combinada 11/12', 238.00, 1, 'En stock', '', ''),
(16, 'Matraca combinada 13/14', 611.00, 1, 'En stock', '', ''),
(17, 'Matraca combinada 17/15', 488.00, 1, 'En stock', '', ''),
(18, 'Llave inglesa surtek 13 mm', 420.00, 1, 'En stock', '', ''),
(19, 'Llave inglesa craftsman 12/14 mm', 229.00, 2, 'En stock', '', ''),
(20, 'Llave inglesa surtek 14mm/114m', 384.00, 1, 'En stock', '', ''),
(21, 'Llave inglesa stil grip 9/16', 663.00, 1, 'En stock', '', ''),
(22, 'Lavve inglesa surtek 115/15m', 408.00, 1, 'En stock', '', ''),
(23, 'Lavve inglesa surtek 114/14m', 318.00, 1, 'En stock', '', ''),
(24, 'Llave inglesa surtek 17.4mm * 11¨/16', 54.00, 1, 'En stock', '', ''),
(25, 'Llave inglesa surtek 17.4mm - 11/16', 180.00, 1, 'En stock', '', ''),
(26, 'Llave inglesa surtek 15.8 .5/8', 130.00, 1, 'En stock', '', ''),
(34, 'Paquete-llave 5(1/2 12.7mm )', 560.00, 1, 'En stock', '', ''),
(106, 'Llaver inglesa urrer 3*8 9.5m', 170.00, 1, 'En stock', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `ID_usuario` int(11) NOT NULL,
  `Nombre` varchar(200) NOT NULL,
  `Correo` varchar(100) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `tipo_usuario` enum('admin','user') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`ID_usuario`, `Nombre`, `Correo`, `contraseña`, `telefono`, `tipo_usuario`) VALUES
(1, 'Administrador', 'administrador@gmail.com', 'administrador0101', '4495396286', 'admin'),
(2, 'Usuario 1', 'usuario@gmail.com', 'usuario123', '4492569670', 'user');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `herramientas`
--
ALTER TABLE `herramientas`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `reciclaje`
--
ALTER TABLE `reciclaje`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`ID_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `herramientas`
--
ALTER TABLE `herramientas`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=386;

--
-- AUTO_INCREMENT de la tabla `reciclaje`
--
ALTER TABLE `reciclaje`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `ID_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
