const express = require('express');
const { engine } = require('express-handlebars');
const myconnection = require('express-myconnection');
const mysql = require('mysql');
const session = require('express-session');
const bodyParser = require('body-parser');
const loginRouter = require('./router/loginR');



const app = express();
const PORT = 1000;

// Configuración de Handlebars
app.set('views', __dirname + '/views'); 
app.engine('.hbs', engine({ extname: '.hbs' }));
app.set('view engine', 'hbs');

const Handlebars = require('handlebars');

// Definición del helper para formatear precios
Handlebars.registerHelper('formatearPrecio', function(precio) {
    return `$${precio.toFixed(2)}`;
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(myconnection(mysql, {
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database: 'inventariotaller'
}, 'single'));

app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: false
}));

// Rutas
app.use('/', loginRouter);


// Ruta para manejar la búsqueda
app.get('/buscar', (req, res) => {
    const query = req.query.query; // búsqueda

    //  buscar en la BD
    const sqlQuery = `SELECT * FROM herramientas WHERE Nombre LIKE ? `;
    const searchTerm = `%${query}%`;

    req.getConnection((err, connection) => {
        if (err) return res.status(500).send('Error de conexión a la base de datos');

        connection.query(sqlQuery, [searchTerm], (error, results) => {
            if (error) return res.status(500).send('Error al realizar la búsqueda');

            // error bus
            if (results.length === 0) {
                return res.render('user', { 
                    herramientas: results, 
                    error: '¡Ups! Esa herramienta no existe.',
                    name: req.session.name // nombre del usuario 
                });
            }

            // 
            res.render('user', { 
                herramientas: results,
                name: req.session.name // 
            });
        });
    });
});




// Inicia el servidor
app.listen(PORT, () => {
    console.log('Corre en el puerto', PORT);
});
