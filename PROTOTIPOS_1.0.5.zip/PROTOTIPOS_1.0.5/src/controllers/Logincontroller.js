// controllers/Logincontroller.js

const mysql = require('mysql');
const bcrypt = require('bcrypt');

// Configuración de la conexión a la base de datos
const db = mysql.createConnection({
    host: 'localhost', 
    user: 'root', 
    password: '', 
    database: 'inventariotaller' 
});

// Conectar a la base de datos
db.connect((err) => {
    if (err) {
        console.error('Error al conectar a la base de datos: ' + err.stack);
        return;
    }
    console.log('Conectado a la base de datos como id ' + db.threadId);
});

// Definición de funciones del controlador


function funcion1(req, res) {
    res.render('login', { mensaje: 'Esta es la página de la función 1' });
}



function admin(req, res) {
    if (req.session.loggedin && req.session.tipo_usuario === 'admin') {
        // Consulta para obtener todas las herramientas
        db.query('SELECT * FROM herramientas ', (err, herramientas) => {
            if (err) {
                return res.status(500).send('Error en la base de datos');
            }

            // Renderiza la página del administrador y pasa los datos de herramientas
            res.render('admin', { herramientas }); 
        });
    } else {
        res.redirect('/login');
    }
}

function user(req, res) {
    if (req.session.loggedin && req.session.tipo_usuario === 'user') {
        // Consulta para obtener todas las herramientas
        db.query('SELECT * FROM herramientas', (err, herramientas) => {
            if (err) {
                return res.status(500).send('Error en la base de datos');
            }

            // Renderiza la página del usuario y pasa los datos de herramientas
            res.render('user', { herramientas }); 
        });
    } else {
        res.redirect('/login');
    }
}

function index(req, res) {
    if (req.session.loggedin) {
        return res.redirect('/'); // Redirige a la página de inicio si ya está logueado
    }
    res.render('login/index'); // Renderiza la vista de login
}

function auth(req, res) {
    const { correo, contraseña } = req.body;

    // Realiza la consulta a la base de datos
    db.query('SELECT * FROM usuario WHERE Correo = ?', [correo], (err, userdata) => {
        if (err) return res.status(500).send('Error en la base de datos');
        if (userdata.length > 0) {
            const user = userdata[0];
            // Comparar las contraseñas
            if (contraseña === user.contraseña) { // No uses bcrypt por el momento
                req.session.loggedin = true;
                req.session.name = user.Nombre;
                req.session.tipo_usuario = user.tipo_usuario;

                if (user.tipo_usuario === 'admin') {
                    return res.redirect('/admin');
                } else {
                    return res.redirect('/user');
                }
            } else {
                return res.render('login/index', { error: 'Contraseña incorrecta.' });
            }
        } else {
            return res.render('login/index', { error: 'Usuario no encontrado.' });
        }
    });
}


function funcion1(req, res) {
    res.render('login', { mensaje: 'Esta es la página de la función 1' });
}
function funcion3(req, res) {
    res.render('alta', { mensaje: 'Esta es la página de la función 1' });
}

function altaHerramienta(req, res) {
    const { Nombre, Precio, Cantidad, Estado, Notas } = req.body;

    // Crear la consulta SQL para insertar una nueva herramienta sin imagen
    const query = 'INSERT INTO herramientas (Nombre, Precio, Cantidad, Estado, Notas) VALUES (?, ?, ?, ?, ?)';

    // Ejecutar la consulta
    db.query(query, [Nombre, Precio, Cantidad, Estado, Notas], (err, result) => {
        if (err) {
            console.error('Error al insertar la herramienta: ' + err.stack);
            return res.status(500).send('Error en la base de datos');
        }

        // Redirigir al panel de administración después de la alta
        res.redirect('/admin');
    });
}


function moverAReciclaje(req, res) {
    const id = req.params.id;

    const queryMover = `
        INSERT INTO reciclaje (ID, Nombre, Precio, Cantidad, Estado, Imagen, Notas)
        SELECT ID, Nombre, Precio, Cantidad, Estado, Imagen, Notas 
        FROM herramientas 
        WHERE ID = ?;
    `;

    db.query(queryMover, [id], (err, result) => {
        if (err) {
            return res.status(500).send('Error al mover la herramienta a reciclaje');
        }

        const queryBorrar = 'DELETE FROM herramientas WHERE ID = ?';
        db.query(queryBorrar, [id], (err, result) => {
            if (err) {
                return res.status(500).send('Error al eliminar la herramienta');
            }

            // Redirigir a la página de administración después de mover al reciclaje
            res.redirect('/admin');
        });
    });
}

function herramientasReciclaje(req, res) {
    if (req.session.loggedin && req.session.tipo_usuario === 'admin') {
        // Consulta para obtener todas las herramientas en reciclaje
        db.query('SELECT * FROM reciclaje', (err, herramientas) => {
            if (err) {
                return res.status(500).send('Error en la base de datos');
            }

            // Renderiza la página de reciclaje y pasa los datos de herramientas
            res.render('reciclaje', { herramientas });
        });
    } else {
        res.redirect('/login');
    }
}


function modificaHerramienta(req,res){
    const rows = document.querySelectorAll('#tabla-herramientas tr');
            const editForm = document.getElementById('editForm');

            rows.forEach(row => {
                row.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    const nombre = this.getAttribute('data-nombre');
                    const precio = this.getAttribute('data-precio');
                    const cantidad = this.getAttribute('data-cantidad');
                    const estado = this.getAttribute('data-estado');
                    const notas = this.getAttribute('data-notas');

                    // Rellenar el formulario con los datos de la fila seleccionada
                    document.getElementById('id').value = id;
                    document.getElementById('nombre').value = nombre;
                    document.getElementById('precio').value = precio;
                    document.getElementById('cantidad').value = cantidad;
                    document.getElementById('estado').value = estado;
                    document.getElementById('notas').value = notas;

                    // Mostrar el formulario de edición
                    editForm.classList.remove('hidden');
                });
    });
}


function register(req, res) {
    res.render('login/register'); // Renderiza la vista de registro
}

function storeUser(req, res) {
    const data = req.body;
    // Implementar la lógica para almacenar el usuario
}

function logout(req, res) {
    req.session.destroy();
    res.redirect('/login'); // Redirige a la vista de login
}

// Exportar todas las funciones, incluyendo funcion2
module.exports = {
    index,
    auth,
    register,
    storeUser,
    logout,
    admin,
    user,
    altaHerramienta,
    modificaHerramienta,
    funcion1,
    moverAReciclaje,
    herramientasReciclaje,
};
