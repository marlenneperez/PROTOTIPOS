const express = require('express');
const router = express.Router();
const loginController = require('../controllers/Logincontroller');
const controlador = require('../controllers/Logincontroller');

//quien borre este lo voy a navajear tampoco la const de controlador
router.get('/login', controlador.funcion1
);

// Ruta para login una herramienta al reciclaje

// Mostrar herramientas en reciclaje
// Archivo de rutas, por ejemplo: routes/admin.js

// Restaurar herramienta desde reciclaje a herramientas
router.get('/admin/reciclaje', loginController.herramientasReciclaje);


// Mover una herramienta al reciclaje
// Mover una herramienta al reciclaje
router.get('/login/mover/:id', loginController.moverAReciclaje);



// Ruta para mostrar el formulario de inicio de sesión
router.get('/login', loginController.index);

// Ruta para autenticar el usuario
router.post('/login', loginController.auth);

// Ruta para el registro
router.get('/register', loginController.register);
router.post('/register', loginController.storeUser);

// Ruta para cerrar sesión
//router.get('/logout', loginController.logout);

router.get('/admin', loginController.admin);

router.get('/user', loginController.user);

// Rutas para el panel de admin y usuario
router.get('/admin', (req, res) => {
    if (req.session.loggedin && req.session.tipo_usuario === 'admin') {
        res.render('admin'); 
    } else {
        res.redirect('/login');
    }
});

router.get('/', (req, res) => {
    if (req.session.loggedin) {
        res.redirect('/user'); // Redirige al usuario logueado
    } else {
        res.redirect('/login'); // Redirige al login si no está logueado
    }
});

//mostrar el formulario de alta 
router.get('/admin/alta', (req, res) => {
    if (req.session.loggedin && req.session.tipo_usuario === 'admin') {
        res.render('alta'); // agregar herramientas
    } else {
        res.redirect('/login');
    }
});

//mostrar el formulario de modifica 
router.get('/admin/modifica', (req, res) => {
    if (req.session.loggedin && req.session.tipo_usuario === 'admin') {
        res.render('modifica'); // modifica herramientas
    } else {
        res.redirect('/login');
    }
});

// Ruta para manejar el alta de la herramienta
router.post('/admin/alta', loginController.altaHerramienta);
router.post('/admin/modifica', loginController.modificaHerramienta);

module.exports = router;
